# AI/Data Engineering Projects by Tara A.C.

This repository contains structured projects aligned with healthcare data, AI/ML, and cloud engineering experience.
