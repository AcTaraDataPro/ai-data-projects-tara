import pandas as pd

def extract_data(filepath):
    print("Loading data...")
    return pd.read_csv(filepath)

def transform_data(df):
    print("Transforming data...")
    df = df.drop_duplicates()
    df = df.fillna(0)
    df['is_high_cost'] = df['claim_amount'] > 10000
    df['is_fraud'] = (df['is_high_cost'] & (df['provider_id'].isin(['X123', 'Y456'])))
    return df

def load_data(df, output_path):
    print("Saving transformed data...")
    df.to_csv(output_path, index=False)

if __name__ == "__main__":
    data = extract_data("../data/claims_sample.csv")
    clean_data = transform_data(data)
    load_data(clean_data, "../data/claims_output.csv")
